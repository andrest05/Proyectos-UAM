console.log("#HELLO WORLD");
var n1= 8;
var n2= 9;
var s= n1+n2
console.log("Resultado suma :" + s);
var c= n1*n2
console.log("Resltado multiplacacion :" + c)
var a= Math.sqrt(1249)
var b= Math.trunc(a)
console.log("Resultado raiz 1249 :" + b)
var c = 10000;
var j = 2;
var numerosPrimos = [];

for (; j < c; j++) {

  if (primo(j)) {
    numerosPrimos.push(j);
  }
  
}

console.log(numerosPrimos);

function primo(numero) {

  for (var i = 2; i < numero; i++) {

    if (numero % i === 0) {
      return false;
    }

  }

  return numero !== 1;}                                                                                                